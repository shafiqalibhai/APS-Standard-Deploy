<?php
require_once('app-util.php');
require_once('file-util.php');
require_once('update.php');

function find_schema_version($db_id) {
    mysql_db_connect(get_db_address($db_id),
          get_db_login($db_id),
          get_db_password($db_id),
          get_db_name($db_id));

	$schema_id = 0;
	$result = mysql_query("SELECT `schema_version` FROM `".get_db_prefix($db_id)."system` WHERE `name`='system' AND `type`='module'");
	if ($result) {
		$schema_id = mysql_result($result, 0);
	}
	if (!$schema_id) {
		$message = "Database is broken, DB schema ID can not be found! ". mysql_error();
		exit(1);
	}
	if ($schema_id < 6053) { 
		// Workaround for Drupal-6.14-3 schema version not updated
		$res = mysql_query("show create table `".get_db_prefix($db_id)."system`");
		if ($res) {
			$row = mysql_fetch_assoc($res);
			$cTable = $row['Create Table'];
			if (preg_match("/KEY `type_name`/", $cTable)) {
				// In Drupal-6.14-3 schema version was not updated, so consider version by latest DB schema change
				$schema_id = 6053;
			}
		}
	}

	return $schema_id;
}

function upgrade_app($from_ver, $from_rel, $config_files, $db_ids, $psa_modify_hash, $db_modify_hash, $settings_modify_hash, $crypt_settings_modify_hash, $settings_enum_modify_hash, $additional_modify_hash){
	$upgrade_schema_files = array();
// $upgrade_schema_files = get_upgrade_schema_files($argv[2], $argv[3]);
// 6048 - schema version for 6.9
	$current_schema_version = find_schema_version('main');
	
	if ($current_schema_version < 6049) {
		$upgrade_schema_files = array('upgrade-6.1.sql' => 'main'); // array('upgrade-1.0-1.sql' => 'main')
	} elseif ($current_schema_version < 6051) {
		$upgrade_schema_files = array('upgrade-6.10.sql' => 'main'); 
	} elseif ($current_schema_version < 6052) {
		$upgrade_schema_files = array('upgrade-6.12.sql' => 'main');
	} elseif ($current_schema_version < 6053) {
		$upgrade_schema_files = array('upgrade-6.13.sql' => 'main');
	} elseif ($current_schema_version < 6055) {
		$upgrade_schema_files = array('upgrade-6.15.sql' => 'main');
	}
    configure($config_files, $upgrade_schema_files, $db_ids, $psa_modify_hash, $db_modify_hash, $settings_modify_hash, $crypt_settings_modify_hash, $settings_enum_modify_hash, $additional_modify_hash);

	mysql_query("UPDATE `".get_db_prefix('main')."system` SET `schema_version`='6055' WHERE `name`='system' AND `type`='module'");
	mysql_query("UPDATE `".get_db_prefix('main')."system` SET `schema_version`='6000' 
					WHERE CONVERT( `".get_db_prefix('main')."system`.`filename` USING utf8 ) = 'modules/dblog/dblog.module' LIMIT 1");
/*
    $my_cwd = getcwd();
    chdir(get_web_dir("/"));
    if("6.1" == $from_ver){
	$update_arr = array(
	    'system' => '6048',
	    'comment' => '6004',
	);
    }	
    else{
        $update_arr = array(
	    'system' => '6048',
	    'comment' => '6004',
	    'update' => '6001'
	);
    }
    my_update($update_arr);
    chdir($my_cwd);
*/
    return 0;
}

function set_offline() {
	mysql_query("UPDATE `".get_db_prefix($db_id)."variable` SET `value`='s:1:\"1\";' WHERE `name`='site_offline'");
	mysql_query("DELETE FROM `".get_db_prefix($db_id)."cache`");
}
function set_online() {
	mysql_query("UPDATE `".get_db_prefix($db_id)."variable` SET `value`='s:1:\"0\";' WHERE `name`='site_offline'");
	mysql_query("DELETE FROM `".get_db_prefix($db_id)."cache`");
}
?>
