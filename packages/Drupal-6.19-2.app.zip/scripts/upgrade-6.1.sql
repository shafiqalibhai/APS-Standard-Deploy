DELETE FROM `@@DB_MAIN_PREFIX@@cache`;
UPDATE `@@DB_MAIN_PREFIX@@menu_router` SET `load_functions`='a:1:{i:1;s:22:\"user_uid_optional_load\";}', `to_arg_functions`='a:1:{i:1;s:24:\"user_uid_optional_to_arg\";}' WHERE `path`='user/%' AND `to_arg_functions`='a:1:{i:1;s:19:\"user_current_to_arg\";}';
ALTER TABLE `@@DB_MAIN_PREFIX@@menu_router` MODIFY `load_functions` text;
ALTER TABLE `@@DB_MAIN_PREFIX@@menu_router` MODIFY `to_arg_functions` text;
ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` DROP INDEX `src`;
ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` ADD INDEX `src_language` (`src`, `language`);
ALTER TABLE `@@DB_MAIN_PREFIX@@users` ADD `signature_format` SMALLINT NOT NULL DEFAULT 0;
ALTER TABLE `@@DB_MAIN_PREFIX@@menu_router` ADD INDEX `tab_root_weight_title` (`tab_root`(64),`weight`,`title`);
ALTER TABLE `@@DB_MAIN_PREFIX@@system` ADD INDEX `type_name` (`type`(12), `name`);
ALTER TABLE `@@DB_MAIN_PREFIX@@watchdog` CHANGE `referer` `referer` TEXT DEFAULT NULL;

SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE IF NOT EXISTS `@@DB_MAIN_PREFIX@@semaphore` (
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  `expire` double NOT NULL,
  PRIMARY KEY  (`name`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` DROP INDEX `src_language`;
ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` DROP KEY `dst_language`;
ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` ADD INDEX `src_language_pid` (`src`, `language`, `pid`);
ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` ADD UNIQUE KEY `dst_language_pid` (`dst`, `language`, `pid`);

