DELETE FROM `@@DB_MAIN_PREFIX@@cache`;
update `@@DB_MAIN_PREFIX@@users` set name = '@@ADMIN_NAME@@', pass = '@@ADMIN_PASSWORD@@', mail = '@@ADMIN_EMAIL@@' where uid=1;
UPDATE `@@DB_MAIN_PREFIX@@variable` SET `value`='@@VAR_ADMIN_EMAIL@@' WHERE `name`='site_mail';
UPDATE `@@DB_MAIN_PREFIX@@variable` SET `value`='@@VAR_TITLE@@' WHERE `name`='site_name';