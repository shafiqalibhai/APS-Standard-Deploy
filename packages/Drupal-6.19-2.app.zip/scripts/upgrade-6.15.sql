SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE IF NOT EXISTS `@@DB_MAIN_PREFIX@@semaphore` (
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  `expire` double NOT NULL,
  PRIMARY KEY  (`name`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` DROP INDEX `src_language`;
ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` DROP KEY `dst_language`;
ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` ADD INDEX `src_language_pid` (`src`, `language`, `pid`);
ALTER TABLE `@@DB_MAIN_PREFIX@@url_alias` ADD UNIQUE KEY `dst_language_pid` (`dst`, `language`, `pid`);


